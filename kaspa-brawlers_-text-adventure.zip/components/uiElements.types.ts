
export interface StatBarProps {
  label: string;
  value: number;
  maxValue: number;
  colorClass?: string;
}
